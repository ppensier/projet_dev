var profile = {
    resourceTags : {
        amd : function(filename, mid) {
            "use strict";
            return (/\.js$/).test(filename);
        }
    }
};