// This file is automatically rebuilt by the Cesium build process.
var gallery_demos = [{
  "name": "3D Models",
  "date": 1425271943430,
  "img": "3D Models.jpg"
}, {
  "name": "Billboards",
  "date": 1423670207235,
  "img": "Billboards.jpg"
}, {
  "name": "Box",
  "date": 1422938045933,
  "img": "Box.jpg"
}, {
  "name": "CZML",
  "date": 1425273106060,
  "img": "CZML.jpg"
}, {
  "name": "Camera Tutorial",
  "date": 1422335009070,
  "img": "Camera Tutorial.jpg"
}, {
  "name": "Camera",
  "date": 1422938045946,
  "img": "Camera.jpg"
}, {
  "name": "Cesium Inspector",
  "date": 1425271943441,
  "img": "Cesium Inspector.jpg"
}, {
  "name": "Cesium Widget",
  "date": 1422335009101,
  "img": "Cesium Widget.jpg"
}, {
  "name": "Circles and Ellipses",
  "date": 1422938045956,
  "img": "Circles and Ellipses.jpg"
}, {
  "name": "Corridor",
  "date": 1422938045962,
  "img": "Corridor.jpg"
}, {
  "name": "Custom DataSource",
  "date": 1422938045972,
  "img": "Custom DataSource.jpg"
}, {
  "name": "Cylinders and Cones",
  "date": 1422938045973,
  "img": "Cylinders and Cones.jpg"
}, {
  "name": "GeoJSON and TopoJSON",
  "date": 1425273106060,
  "img": "GeoJSON and TopoJSON.jpg"
}, {
  "name": "GeoJSON simplestyle",
  "date": 1425681172579,
  "img": "GeoJSON simplestyle.jpg"
}, {
  "name": "Geometry and Appearances",
  "date": 1422938046025,
  "img": "Geometry and Appearances.jpg"
}, {
  "name": "Hello World",
  "date": 1422335009258,
  "img": "Hello World.jpg"
}, {
  "name": "Imagery Adjustment",
  "date": 1422335009258,
  "img": "Imagery Adjustment.jpg"
}, {
  "name": "Imagery Layers Manipulation",
  "date": 1422335009273,
  "img": "Imagery Layers Manipulation.jpg"
}, {
  "name": "Imagery Layers",
  "date": 1422335009273,
  "img": "Imagery Layers.jpg"
}, {
  "name": "KML",
  "date": 1425273106060,
  "img": "KML.jpg"
}, {
  "name": "Labels",
  "date": 1425498228841,
  "img": "Labels.jpg"
}, {
  "name": "Map Pins",
  "date": 1422938047635,
  "img": "Map Pins.jpg"
}, {
  "name": "Materials",
  "date": 1422335009305,
  "img": "Materials.jpg"
}, {
  "name": "Picking",
  "date": 1422938046032,
  "img": "Picking.jpg"
}, {
  "name": "Polygon",
  "date": 1422938046033,
  "img": "Polygon.jpg"
}, {
  "name": "Polyline Volume",
  "date": 1422938046042,
  "img": "Polyline Volume.jpg"
}, {
  "name": "Polyline",
  "date": 1422938046051,
  "img": "Polyline.jpg"
}, {
  "name": "Rectangle",
  "date": 1422938046056,
  "img": "Rectangle.jpg"
}, {
  "name": "Spheres and Ellipsoids",
  "date": 1422938046061,
  "img": "Spheres and Ellipsoids.jpg"
}, {
  "name": "Terrain",
  "date": 1425273106060,
  "img": "Terrain.jpg"
}, {
  "name": "Wall",
  "date": 1422938046071,
  "img": "Wall.jpg"
}, {
  "name": "Web Map Service (WMS)",
  "date": 1422335009539,
  "img": "Web Map Service (WMS).jpg"
}];